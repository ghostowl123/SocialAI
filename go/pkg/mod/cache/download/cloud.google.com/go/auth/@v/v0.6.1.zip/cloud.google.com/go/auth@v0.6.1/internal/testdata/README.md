# testdata

The private key used in these tests is of the correct format, but does not
really allow access to any cloud project. DO NOT put any real credentials in
this folder, it is strictly for use in unit tests.
